import os
import sys

import rclpy

from foundation_pose.fake_realsense_node import FakeRealsenseNode
from threading import Thread

from rclpy.node import Node
from std_msgs.msg import String
from rclpy.executors import SingleThreadedExecutor
import pytest
import time


from sensor_msgs.msg import Image as rosImg
from sensor_msgs.msg import  CameraInfo
from geometry_msgs.msg import Pose, PoseStamped

from cv_bridge import CvBridge
import cv2

import multiprocessing

multiprocessing.set_start_method('spawn')


folder_path = os.path.dirname(os.path.abspath(__file__))

TEST_DATA_PATH=folder_path + '/test_data/mustred0'

class TestFakeRealsenseSubscriber(Node):
  def __init__(self):
    super().__init__('test_subscriber')

    # Subscribers
    self.sub_color =  self.create_subscription(rosImg,
                                                '/camera/camera/color/image_raw',
                                                self.grab_color, 10)
    self.sub_depth = self.create_subscription(rosImg,
                                                '/camera/camera/aligned_depth_to_color/image_raw',
                                                self.grab_depth, 10)



    self.message_received = {
      "color":None,
      "depth":None,
      "cam_info":None,
      "mask":None
    }

  # callbacks
  def grab_color(self, msg):
    self.get_logger().info('grab_color called! ')
    self.message_received["color"] = msg.data

  def grab_depth(self, msg):
    self.get_logger().info('grab_depth called! ')
    self.message_received["depth"] = msg.data



@pytest.fixture
def ros_setup():
    rclpy.init()
    test_node = TestFakeRealsenseSubscriber()
    executor = SingleThreadedExecutor()
    executor.add_node(test_node)
    yield test_node, executor
    test_node.destroy_node()
    rclpy.shutdown()

def run_fake_realsense_node():

    rclpy.init()
    pub_node = FakeRealsenseNode()
    try:
        rclpy.spin(pub_node)
    finally:
        pub_node.destroy_node()
        rclpy.shutdown()

def test_color_message_published(ros_setup):
    test_node, executor = ros_setup

    # Start the FakeRealsenseNode in a separate process
    pub_process = multiprocessing.Process(target=run_fake_realsense_node, daemon=True)
    pub_process.start()

    # Wait for the publisher to initialize
    time.sleep(1)  # Adjust this value based on the expected setup time

    try:
        # Run the executor and check for messages
        for _ in range(4):
            executor.spin_once(timeout_sec=0.1)
            if test_node.message_received["color"]:
                break
            else:
                test_node.get_logger().info('Waiting for messages...')

        assert test_node.message_received["color"] is not None, \
            f"Color image was not received"
    finally:
        # Terminate the publisher process
        pub_process.terminate()
        pub_process.join()

"""
def test_color_message_published(ros_setup):
    test_node, executor = ros_setup

    pub_node = FakeRealsenseNode()
    pub_thread = Thread(target=lambda: rclpy.spin(pub_node), daemon=True)
    pub_thread.start()

    # Wait for the publisher to initialize
    time.sleep(1)  # Adjust this value based on the expected setup time
    # Run the executor and check for messages
    try:
        for _ in range(4):
            executor.spin_once(timeout_sec=0.1)
            if test_node.message_received["color"]:
                break
            else:
              test_node.get_logger().info('Waiting for messages...')

        assert test_node.message_received["color"] != None , \
            f"color image was not received "
    finally:
        pub_node.destroy_node()
        pub_thread.join()


def test_depth_message_published(ros_setup):
    test_node, executor = ros_setup

    pub_node = FakeRealsenseNode()
    pub_thread = Thread(target=lambda: rclpy.spin(pub_node), daemon=True)
    pub_thread.start()

     # Wait for the publisher to initialize
    time.sleep(1)  # Adjust this value based on the expected setup time
    # Run the executor and check for messages

    # Run the executor and check for messages
    try:
        for _ in range(4):
            executor.spin_once(timeout_sec=0.1)
            if test_node.message_received["depth"]:
                break
            else:
              test_node.get_logger().info('Waiting for messages...')

        assert test_node.message_received["depth"] != None , \
            f"depth image was not received "
    finally:
        pub_node.destroy_node()
        pub_thread.join()
"""